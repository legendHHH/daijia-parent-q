package com.lee.mp;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lee.mp.eneity.User;
import com.lee.mp.mapper.UserMapper;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
//@MapperScan("com.lee.mp.mapper")
public class CRUDTests {
    @Resource
    private UserMapper userMapper;

    @Test
    public void testSelectList() {
        List<User> userList = userMapper.selectList(null);
        userList.forEach(System.out::println);
    }

    @Test
    public void testInsert() {
        User user = new User();
        user.setName("jack");
        user.setAge(18);
        user.setEmail("123456999@qq.com");
        int result = userMapper.insert(user);
        System.out.println(result); //影响的行数
        System.out.println(user); //id自动回填
    }

    @Test
    public void testSelectById() {
        User user = userMapper.selectById(1856267228520308738L);
        System.out.println(user);
    }

    @Test
    public void testUpdateById() {
        User user = userMapper.selectById(1856267228520308738L);
        System.out.println(user);
        user.setName("jack111");
        user.setAge(108);
        user.setEmail("3456999@qq.com");
        int result = userMapper.updateById(user);
        System.out.println(result); //影响的行数
        System.out.println(user);
    }

    @Test
    public void testDeleteById() {
        int result = userMapper.deleteById(1856267228520308738L);
        System.out.println(result); //影响的行数
    }

    @Test
    public void testSelectByCondition() {
        //select * from user where name=? and age=?
        LambdaQueryWrapper<User> userWrapper = new LambdaQueryWrapper<>();
        userWrapper.eq(User::getName, "Jack");
        userWrapper.eq(User::getAge, 20);
        List<User> userList = userMapper.selectList(userWrapper);
        userList.forEach(System.out::println);

        //select * from user where age>?
        LambdaQueryWrapper<User> userWrapper2 = new LambdaQueryWrapper<>();
        userWrapper2.gt(User::getAge, 20);
        List<User> userList2 = userMapper.selectList(userWrapper2);
        userList2.forEach(System.out::println);

        //select * from user where name like ?
        LambdaQueryWrapper<User> userWrapper3 = new LambdaQueryWrapper<>();
        userWrapper3.like(User::getName, "Ja");
        List<User> userList3 = userMapper.selectList(userWrapper3);
        userList3.forEach(System.out::println);
    }

    @Test
    public void testPage() {
        Page<User> userPage = new Page<>(1, 3);
        IPage<User> page = userMapper.selectPage(userPage, null);

        List<User> records = page.getRecords();
        records.forEach(System.out::println);

        long total = page.getTotal();
        System.out.println("total:" + total);
    }
}